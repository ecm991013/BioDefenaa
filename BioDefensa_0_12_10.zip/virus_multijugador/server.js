'use strict';

// Servidor multijugador ligero, sin dependencias externas.
// Sirve la web y sincroniza las partidas mediante peticiones HTTP periódicas.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';
const ROOT = __dirname;
const rooms = new Map();
const COLORS = ['rojo', 'azul', 'amarillo', 'verde'];
const EMOTES = ['😂','😡','😱','😭','😎','👍','👎','❤️','🔥','🤔','👏','🥳'];
const COLOR_NAMES = { rojo: 'Corazón', azul: 'Cerebro', amarillo: 'Estómago', verde: 'Hueso', bionico: 'Brazo biónico', comodin: 'Universal' };
const TREATMENTS = {
  swap: { title: 'Intercambio orgánico', description: 'Intercambia un órgano tuyo con uno de otro jugador.' },
  steal: { title: 'Extracción', description: 'Roba un órgano sano o infectado de otro jugador.' },
  spread: { title: 'Propagación', description: 'Traslada un virus de uno de tus órganos infectados a un órgano rival del mismo color.' },
  glove: { title: 'Guantes de cuarentena', description: 'Los demás jugadores descartan su mano y roban tres cartas nuevas.' },
  body: { title: 'Cambio de cuerpo', description: 'Intercambia todo tu cuerpo con el de otro jugador.' },
  shield: { title: 'Blindaje', description: 'Protege un órgano inmunizado.' },
  matasanos: { title: 'Matasanos', description: 'Retira el blindaje de un órgano rival sin quitar sus medicinas ni su inmunización.' }
};

function uid() { return crypto.randomBytes(8).toString('hex'); }
function cleanName(value) {
  return String(value || '').replace(/[<>]/g, '').trim().slice(0, 18);
}
function roomCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do { code = Array.from({ length: 5 }, () => alphabet[Math.floor(Math.random() * alphabet.length)]).join(''); }
  while (rooms.has(code));
  return code;
}
function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}
function makeDeck() {
  const deck = [];
  for (const color of COLORS) for (let i = 0; i < 5; i++) deck.push({ id: uid(), kind: 'organ', color });
  // Carta única por partida: órgano comodín que ya viene inmunizado.
  deck.push({ id: uid(), kind: 'organ', color: 'bionico', bionic: true });
  for (const color of COLORS) for (let i = 0; i < 4; i++) deck.push({ id: uid(), kind: 'virus', color });
  for (let i = 0; i < 2; i++) deck.push({ id: uid(), kind: 'virus', color: 'comodin' });
  for (const color of COLORS) for (let i = 0; i < 5; i++) deck.push({ id: uid(), kind: 'medicine', color });
  for (let i = 0; i < 2; i++) deck.push({ id: uid(), kind: 'medicine', color: 'comodin' });
  for (const treatment of Object.keys(TREATMENTS)) {
    const copies = treatment === 'body' ? 1 : 2; // Cambio de cuerpo: una sola copia; Blindaje y Matasanos: dos de cada uno.
    for (let i = 0; i < copies; i++) deck.push({ id: uid(), kind: 'treatment', treatment });
  }
  return shuffle(deck); // 74 cartas: incluye un único Brazo biónico y Cambio de cuerpo, dos Blindajes y dos Matasanos
}
function log(room, message, actorId = null) {
  const entry = { id: uid(), message, at: Date.now(), actorId };
  room.log.unshift(entry);
  room.log = room.log.slice(0, 18);

  // Cola de eventos de jugada independiente de lastMove. Así ningún turno
  // pisa el mensaje anterior antes de que los demás dispositivos lo consulten.
  if (actorId) {
    const actor = room.players.find(p => p.id === actorId);
    room.actionEvents ||= [];
    room.actionEvents.push({
      id: entry.id,
      playerId: actorId,
      playerName: actor?.name || 'Jugador',
      avatarIndex: Number.isInteger(actor?.avatarIndex) ? actor.avatarIndex : 0,
      isAI: Boolean(actor?.isAI),
      message: entry.message,
      at: entry.at
    });
    room.actionEvents = room.actionEvents.slice(-40);
  }

  room.version++;
  room.lastActivity = Date.now();
}
function getPlayer(room, playerId) { return room.players.find(p => p.id === playerId); }
function drawOne(room, player) {
  if (room.deck.length === 0 && room.discard.length > 0) {
    room.deck = shuffle(room.discard.splice(0));
    log(room, 'El mazo se ha mezclado de nuevo.');
  }
  if (room.deck.length) player.hand.push(room.deck.pop());
}
function fillHand(room, player) {
  while (player.hand.length < 3) {
    const before = player.hand.length;
    drawOne(room, player);
    if (player.hand.length === before) break;
  }
}
function organById(player, organId) { return player.organs.find(o => o.id === organId); }
function hasColor(player, color, exceptId = null) {
  return player.organs.some(o => o.color === color && o.id !== exceptId);
}
function modifiersToDiscard(room, organ) {
  room.discard.push(...organ.viruses, ...organ.medicines);
}
function applyVirus(room, target, organ, virusCard, actorName, actorId = null) {
  if (isImmunized(organ)) {
    room.discard.push(virusCard);
    log(room, `${actorName} intentó infectar ${COLOR_NAMES[organ.color]}, pero estaba inmunizado y rechazó el virus.`, actorId);
    return;
  }
  if (organ.medicines.length === 1) {
    room.discard.push(virusCard, ...organ.medicines);
    organ.medicines = [];
    log(room, `La medicina neutralizó un virus en ${target.name}.`, actorId);
    return;
  }
  if (organ.viruses.length === 0) {
    organ.viruses.push(virusCard);
    log(room, `${actorName} infectó el órgano ${COLOR_NAMES[organ.color]} de ${target.name}.`, actorId);
    return;
  }
  room.discard.push(virusCard);
  modifiersToDiscard(room, organ);
  target.organs = target.organs.filter(o => o.id !== organ.id);
  log(room, `¡${actorName} destruyó el órgano ${COLOR_NAMES[organ.color]} de ${target.name}!`, actorId);
}
function validateTurn(room, playerId) {
  if (!room.started) throw new Error('La partida todavía no ha comenzado.');
  if (room.finished) throw new Error('La partida ya terminó.');
  if (room.currentPlayerId !== playerId) throw new Error('Todavía no es tu turno.');
}
function nextTurn(room) {
  const currentIndex = room.players.findIndex(p => p.id === room.currentPlayerId);
  if (currentIndex < 0 || room.players.length === 0) return;
  for (let step = 1; step <= room.players.length; step++) {
    const next = room.players[(currentIndex + step) % room.players.length];
    if (next) {
      room.currentPlayerId = next.id;
      fillHand(room, next);
      log(room, `Turno de ${next.name}.`);
      return;
    }
  }
}
function isImmunized(organ) {
  // El Brazo biónico llega inmunizado; los demás órganos requieren dos medicinas.
  return Boolean(organ && (organ.bionic || organ.color === 'bionico' || organ.medicines.length >= 2));
}
function isReadyForMode(room, organ) {
  if (!organ || organ.viruses.length > 0) return false;
  return room.mode === 'classic' || isImmunized(organ);
}
function playerHasWon(room, player) {
  const readyColors = COLORS.filter(color => {
    const organ = player.organs.find(o => o.color === color);
    return isReadyForMode(room, organ);
  }).length;
  const bionicReady = player.organs.some(o => (o.bionic || o.color === 'bionico') && isReadyForMode(room, o));
  // El Brazo biónico sustituye uno de los cuatro órganos de color que falten.
  return readyColors === 4 || (bionicReady && readyColors >= 3);
}
function finishGame(room, winner, message) {
  if (!winner || room.finished) return false;
  room.finished = true;
  room.winnerId = winner.id;
  if (!room.winnerRecordedForGame) {
    room.wins ||= {};
    const previous = room.wins[winner.id];
    room.wins[winner.id] = {
      playerId: winner.id,
      name: winner.name,
      avatarIndex: Number.isInteger(winner.avatarIndex) ? winner.avatarIndex : 0,
      wins: (previous?.wins || 0) + 1
    };
    room.winnerRecordedForGame = true;
  }
  log(room, message || `🏆 ${winner.name} gana la partida.`);
  return true;
}
function checkWinner(room) {
  const winner = room.players.find(p => playerHasWon(room, p));
  if (!winner) return false;
  const goal = room.mode === 'classic' ? 'sus cuatro órganos sanos' : 'sus cuatro órganos inmunizados';
  return finishGame(room, winner, `🏆 ${winner.name} ha completado ${goal} y gana la partida.`);
}
function resetForRematch(room) {
  if (!room.finished) throw new Error('La partida todavía no ha terminado.');
  if (room.players.length < 2) throw new Error('Se necesitan al menos dos jugadores para volver a jugar.');
  const previousWinnerIndex = room.players.findIndex(p => p.id === room.winnerId);
  for (const player of room.players) {
    player.hand = [];
    player.organs = [];
  }
  room.deck = makeDeck();
  room.discard = [];
  room.bionicPlayed = false;
  room.finished = false;
  room.winnerId = null;
  room.winnerRecordedForGame = false;
  room.started = true;
  room.lastMove = null;
  room.actionEvents = [];
  room.emotes = [];
  room.emoteCooldowns = {};
  // El siguiente encuentro comienza con el jugador posterior al ganador anterior.
  const firstIndex = previousWinnerIndex >= 0 ? (previousWinnerIndex + 1) % room.players.length : 0;
  room.currentPlayerId = room.players[firstIndex].id;
  for (const player of room.players) fillHand(room, player);
  room.matchNumber = (room.matchNumber || 1) + 1;
  room.log = [];
  log(room, `🔁 Comienza la partida ${room.matchNumber}. El podio de victorias de esta sala se conserva.`);
  log(room, `Turno de ${room.players[firstIndex].name}.`);
}
function playCard(room, player, action) {
  const cardIndex = player.hand.findIndex(c => c.id === action.cardId);
  if (cardIndex < 0) throw new Error('Esa carta no está en tu mano.');
  const card = player.hand[cardIndex];
  const other = id => getPlayer(room, id);

  if (card.kind === 'organ') {
    if (card.bionic || card.color === 'bionico') {
      if (room.bionicPlayed || player.organs.some(o => o.bionic || o.color === 'bionico')) throw new Error('El Brazo biónico ya apareció en esta partida.');
      player.organs.push({ id: uid(), color: 'bionico', bionic: true, shielded: false, viruses: [], medicines: [] });
      room.bionicPlayed = true;
      log(room, `${player.name} colocó el Brazo biónico: ya está inmunizado y cuenta como uno de los cuatro órganos.`, player.id);
    } else {
      if (hasColor(player, card.color)) throw new Error('Ya tienes ese tipo de órgano.');
      player.organs.push({ id: uid(), color: card.color, shielded: false, viruses: [], medicines: [] });
      log(room, `${player.name} colocó un órgano: ${COLOR_NAMES[card.color]}.`, player.id);
    }
  } else if (card.kind === 'medicine') {
    const organ = organById(player, action.organId);
    if (!organ) throw new Error('Selecciona uno de tus órganos.');
    if (organ.bionic || organ.color === 'bionico') throw new Error('El Brazo biónico ya está inmunizado y no necesita medicinas.');
    if (card.color !== 'comodin' && organ.color !== card.color) throw new Error('La medicina debe coincidir con el color del órgano.');
    if (organ.medicines.length >= 2) throw new Error('Ese órgano ya está inmunizado.');
    if (organ.viruses.length > 0) {
      room.discard.push(...organ.viruses, card);
      organ.viruses = [];
      log(room, `${player.name} curó el órgano ${COLOR_NAMES[organ.color]}.`, player.id);
    } else {
      organ.medicines.push(card);
      log(room, `${player.name} añadió medicina al órgano ${COLOR_NAMES[organ.color]}.`, player.id);
    }
  } else if (card.kind === 'virus') {
    const target = other(action.targetPlayerId);
    if (!target || target.id === player.id) throw new Error('Selecciona a otro jugador.');
    const organ = organById(target, action.organId);
    if (!organ) throw new Error('Selecciona un órgano del rival.');
    if (card.color !== 'comodin' && card.color !== organ.color) throw new Error('El virus no coincide con el color del órgano.');
    applyVirus(room, target, organ, card, player.name, player.id);
  } else if (card.kind === 'treatment') {
    const t = card.treatment;
    if (t === 'swap') {
      const p1 = other(action.targetPlayerId);
      const p2 = other(action.targetPlayerId2);
      if (!p1 || !p2 || p1.id === p2.id) throw new Error('Selecciona dos jugadores distintos.');
      const o1 = organById(p1, action.organId);
      const o2 = organById(p2, action.organId2);
      if (!o1 || !o2) throw new Error('Selecciona los dos órganos que vas a intercambiar.');
      if (o1.shielded || o2.shielded) throw new Error('Un órgano blindado no puede intercambiarse con Intercambio orgánico.');
      if (hasColor(p1, o2.color, o1.id) || hasColor(p2, o1.color, o2.id)) throw new Error('El intercambio dejaría a alguien con dos órganos del mismo tipo.');
      p1.organs = p1.organs.filter(o => o.id !== o1.id); p2.organs = p2.organs.filter(o => o.id !== o2.id);
      p1.organs.push(o2); p2.organs.push(o1);
      log(room, `${player.name} realizó un intercambio de órganos entre ${p1.name} y ${p2.name}.`, player.id);
    } else if (t === 'steal') {
      const target = other(action.targetPlayerId);
      if (!target || target.id === player.id) throw new Error('Selecciona a otro jugador.');
      const organ = organById(target, action.organId);
      if (!organ) throw new Error('Selecciona el órgano que quieres extraer.');
      if (organ.shielded) throw new Error('Ese órgano está blindado y no puede ser extraído.');
      if (hasColor(player, organ.color)) throw new Error('Ya tienes un órgano de ese tipo.');
      target.organs = target.organs.filter(o => o.id !== organ.id); player.organs.push(organ);
      log(room, `${player.name} extrajo un órgano de ${target.name}.`, player.id);
    } else if (t === 'spread') {
      const source = organById(player, action.sourceOrganId);
      const target = other(action.targetPlayerId);
      if (!source || source.viruses.length === 0) throw new Error('Selecciona uno de tus órganos infectados.');
      if (!target || target.id === player.id) throw new Error('Selecciona a otro jugador.');
      const organ = organById(target, action.organId);
      if (!organ || organ.color !== source.color) throw new Error('El objetivo debe tener un órgano del mismo color.');
      const virus = source.viruses.pop();
      applyVirus(room, target, organ, virus, player.name, player.id);
      log(room, `${player.name} propagó una infección.`, player.id);
    } else if (t === 'glove') {
      for (const rival of room.players) if (rival.id !== player.id) {
        room.discard.push(...rival.hand.splice(0));
        fillHand(room, rival);
      }
      log(room, `${player.name} activó los guantes de cuarentena: los demás renovaron su mano.`, player.id);
    } else if (t === 'body') {
      const target = other(action.targetPlayerId);
      if (!target || target.id === player.id) throw new Error('Selecciona a otro jugador.');
      [player.organs, target.organs] = [target.organs, player.organs];
      log(room, `${player.name} intercambió todo su cuerpo con ${target.name}.`, player.id);
    } else if (t === 'shield') {
      const organ = organById(player, action.organId);
      if (!organ) throw new Error('Selecciona uno de tus órganos.');
      if (!isImmunized(organ) || organ.viruses.length > 0) throw new Error('Blindaje solo puede aplicarse a un órgano sano e inmunizado.');
      if (organ.shielded) throw new Error('Ese órgano ya tiene Blindaje.');
      organ.shielded = true;
      log(room, `${player.name} aplicó Blindaje al órgano ${COLOR_NAMES[organ.color]}.`, player.id);
    } else if (t === 'matasanos') {
      const target = other(action.targetPlayerId);
      if (!target || target.id === player.id) throw new Error('Selecciona a otro jugador.');
      const organ = organById(target, action.organId);
      if (!organ || !organ.shielded) throw new Error('Selecciona un órgano rival que tenga Blindaje.');
      organ.shielded = false;
      log(room, `${player.name} utilizó Matasanos y retiró el Blindaje del órgano ${COLOR_NAMES[organ.color]} de ${target.name}. El órgano sigue inmunizado.`, player.id);
    }
  }

  player.hand.splice(cardIndex, 1);
  if (card.kind !== 'medicine' || !room.discard.includes(card)) {
    // Las cartas de órgano y tratamiento se consumen; los virus y medicinas
    // permanecen en el tablero cuando su efecto así lo requiere.
    const stillOnBoard = room.players.some(p => p.organs.some(o => o.viruses.includes(card) || o.medicines.includes(card)));
    if (!stillOnBoard && !room.discard.includes(card) && card.kind !== 'organ') room.discard.push(card);
  }
  checkWinner(room);
}
function serialize(room, playerId) {
  const self = getPlayer(room, playerId);
  return {
    roomId: room.id,
    hostId: room.hostId,
    mode: room.mode || 'immunity',
    lastMove: room.lastMove || null,
    // Eventos recientes emitidos por humanos o IA; el cliente filtra sus propias jugadas.
    actionEvents: (room.actionEvents || []).slice(-40),
    started: room.started,
    finished: room.finished,
    winnerId: room.winnerId,
    roomWins: Object.values(room.wins || {}).sort((a, b) => b.wins - a.wins || a.name.localeCompare(b.name)),
    emotes: (room.emotes || []).slice(-12),
    matchNumber: room.matchNumber || 1,
    currentPlayerId: room.currentPlayerId,
    deckCount: room.deck.length,
    discardCount: room.discard.length,
    version: room.version,
    players: room.players.map(p => ({
      id: p.id, name: p.name, avatarIndex: Number.isInteger(p.avatarIndex) ? p.avatarIndex : null, isHost: p.id === room.hostId, isAI: Boolean(p.isAI),
      cardCount: p.hand.length,
      organs: p.organs.map(o => ({
        id: o.id, color: o.color, bionic: Boolean(o.bionic || o.color === 'bionico'), shielded: Boolean(o.shielded),
        virusCount: o.viruses.length,
        medicineCount: o.medicines.length,
        virusColors: o.viruses.map(v => v.color),
        medicineColors: o.medicines.map(m => m.color)
      }))
    })),
    hand: self ? self.hand.map(c => ({ ...c })) : [],
    log: room.log.slice(0, 12),
    selfId: playerId
  };
}
function chooseAIMove(room, bot) {
  const opponents = room.players.filter(p => p.id !== bot.id);
  const ownMissing = COLORS.filter(color => !bot.organs.some(o => o.color === color));
  const ownInfected = bot.organs.find(o => o.viruses.length > 0);
  const ownNeedsMedicine = bot.organs.find(o => !o.bionic && o.viruses.length === 0 && o.medicines.length < 2);
  const candidates = [];
  // Construye jugadas útiles y válidas; si no encuentra ninguna, descarta una carta.
  for (const card of bot.hand) {
    if (card.kind === 'organ' && ((card.bionic && !room.bionicPlayed && !bot.organs.some(o => o.bionic)) || (!card.bionic && ownMissing.includes(card.color)))) {
      candidates.push({ card, action: { type: 'play', cardId: card.id }, score: card.bionic ? 95 : 100 });
    }
    if (card.kind === 'medicine') {
      const target = ownInfected || (ownNeedsMedicine && (card.color === 'comodin' || card.color === ownNeedsMedicine.color) ? ownNeedsMedicine : null);
      if (target && (card.color === 'comodin' || card.color === target.color)) candidates.push({ card, action: { type: 'play', cardId: card.id, organId: target.id }, score: ownInfected ? 115 : 80 + target.medicines.length });
    }
    if (card.kind === 'virus') {
      for (const rival of opponents) for (const organ of rival.organs) {
        if (organ.viruses.length < 1 && !isImmunized(organ) && (card.color === 'comodin' || card.color === organ.color)) {
          candidates.push({ card, action: { type: 'play', cardId: card.id, targetPlayerId: rival.id, organId: organ.id }, score: organ.medicines.length ? 90 : 70 });
        }
      }
    }
  }
  candidates.sort((a,b) => b.score - a.score);
  for (const candidate of candidates) {
    try { playCard(room, bot, candidate.action); return candidate.action; } catch {}
  }
  const discard = bot.hand[bot.hand.length - 1];
  if (discard) { room.discard.push(discard); bot.hand = bot.hand.filter(c => c.id !== discard.id); log(room, `${bot.name} descartó una carta para reorganizar su estrategia.`, bot.id); }
  return { type: 'discard' };
}
function runAITurn(roomId) {
  const room = rooms.get(roomId);
  if (!room || !room.started || room.finished) return;
  const bot = getPlayer(room, room.currentPlayerId);
  if (!bot?.isAI) return;
  setTimeout(() => {
    const currentRoom = rooms.get(roomId);
    if (!currentRoom || !currentRoom.started || currentRoom.finished) return;
    const currentBot = getPlayer(currentRoom, currentRoom.currentPlayerId);
    if (!currentBot?.isAI) return;
    const previousLogId = currentRoom.log[0]?.id || null;
    chooseAIMove(currentRoom, currentBot);
    const aiLog = currentRoom.log.find(entry => entry.actorId === currentBot.id && entry.id !== previousLogId);
    if (aiLog) {
      currentRoom.lastMove = {
        id: aiLog.id,
        playerId: currentBot.id,
        playerName: currentBot.name,
        message: aiLog.message,
        at: aiLog.at,
        effect: null,
        targetPlayerId: null,
        targetOrganId: null,
        cardKind: null,
        color: null
      };
      const aiEvent = (currentRoom.actionEvents || []).find(event => event.id === aiLog.id);
      if (aiEvent) Object.assign(aiEvent, currentRoom.lastMove, { isAI: true, avatarIndex: Number.isInteger(currentBot.avatarIndex) ? currentBot.avatarIndex : 0 });
    }
    if (!currentRoom.finished) {
      fillHand(currentRoom, currentBot);
      checkWinner(currentRoom);
      if (!currentRoom.finished) nextTurn(currentRoom);
    }
    currentRoom.version++;
    runAITurn(roomId);
  }, 850 + Math.floor(Math.random() * 650));
}

function send(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify(data));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => { body += chunk; if (body.length > 1_000_000) reject(new Error('Petición demasiado grande.')); });
    req.on('end', () => { try { resolve(body ? JSON.parse(body) : {}); } catch { reject(new Error('JSON no válido.')); } });
    req.on('error', reject);
  });
}
function requireRoom(roomId) {
  const room = rooms.get(String(roomId || '').toUpperCase());
  if (!room) throw new Error('No existe esa sala. Revisa el código.');
  room.lastActivity = Date.now();
  return room;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' });
    return res.end();
  }
  try {
    if (url.pathname === '/api/create' && req.method === 'POST') {
      const body = await readBody(req); const name = cleanName(body.name);
      if (!name) return send(res, 400, { error: 'Escribe tu nombre.' });
      const id = roomCode(); const playerId = uid();
      const mode = body.mode === 'classic' ? 'classic' : 'immunity';
      const room = { id, hostId: playerId, mode, bionicPlayed: false, lastMove: null, actionEvents: [], emotes: [], emoteCooldowns: {}, wins: {}, winnerRecordedForGame: false, matchNumber: 1, players: [{ id: playerId, name, avatarIndex: Math.max(0, Math.min(7, Number.isInteger(body.avatarIndex) ? body.avatarIndex : 0)), hand: [], organs: [] }], deck: [], discard: [], started: false, finished: false, winnerId: null, currentPlayerId: null, log: [], version: 1, lastActivity: Date.now() };
      rooms.set(id, room); log(room, `${name} creó la sala.`);
      return send(res, 200, { roomId: id, playerId });
    }
    if (url.pathname === '/api/create-ai' && req.method === 'POST') {
      const body = await readBody(req); const name = cleanName(body.name);
      if (!name) return send(res, 400, { error: 'Escribe tu nombre.' });
      const rivalCount = Math.max(1, Math.min(5, Number.parseInt(body.rivalCount, 10) || 1));
      const id = roomCode(); const playerId = uid();
      const mode = body.mode === 'classic' ? 'classic' : 'immunity';
      const players = [{ id: playerId, name, avatarIndex: Math.max(0, Math.min(7, Number.isInteger(body.avatarIndex) ? body.avatarIndex : 0)), hand: [], organs: [], isAI: false }];
      const botNames = ['NEXUS','VIRION','CELULA-X','PROTEUS','MUTANTE'];
      for (let i=0;i<rivalCount;i++) players.push({ id: uid(), name: botNames[i], avatarIndex: (i+2)%8, hand: [], organs: [], isAI: true });
      const room = { id, hostId: playerId, mode, bionicPlayed: false, lastMove: null, actionEvents: [], emotes: [], emoteCooldowns: {}, wins: {}, winnerRecordedForGame: false, matchNumber: 1, players, deck: [], discard: [], started: false, finished: false, winnerId: null, currentPlayerId: null, log: [], version: 1, lastActivity: Date.now(), againstAI: true };
      rooms.set(id, room); log(room, `${name} inició una partida contra ${rivalCount} ${rivalCount===1?'rival de IA':'rivales de IA'}.`);
      return send(res, 200, { roomId: id, playerId });
    }
    if (url.pathname === '/api/join' && req.method === 'POST') {
      const body = await readBody(req); const name = cleanName(body.name); const room = requireRoom(body.roomId);
      if (!name) return send(res, 400, { error: 'Escribe tu nombre.' });
      if (room.started) return send(res, 400, { error: 'La partida ya comenzó; no se permiten nuevas entradas.' });
      if (room.players.length >= 6) return send(res, 400, { error: 'La sala está llena (máximo 6 jugadores).'});
      const playerId = uid(); room.players.push({ id: playerId, name, avatarIndex: Math.max(0, Math.min(7, Number.isInteger(body.avatarIndex) ? body.avatarIndex : 0)), hand: [], organs: [] });
      log(room, `${name} se unió a la sala.`);
      return send(res, 200, { roomId: room.id, playerId });
    }
    if (url.pathname === '/api/state' && req.method === 'GET') {
      const room = requireRoom(url.searchParams.get('room')); const playerId = url.searchParams.get('player');
      if (!getPlayer(room, playerId)) return send(res, 403, { error: 'No perteneces a esta sala.' });
      return send(res, 200, serialize(room, playerId));
    }
    if (url.pathname === '/api/emote' && req.method === 'POST') {
      const body = await readBody(req); const room = requireRoom(body.roomId); const player = getPlayer(room, body.playerId);
      if (!player) return send(res, 403, { error: 'No perteneces a esta sala.' });
      if (!room.started || room.finished) return send(res, 400, { error: 'Las reacciones están disponibles durante una partida activa.' });
      const emoji = String(body.emoji || '');
      if (!EMOTES.includes(emoji)) return send(res, 400, { error: 'Esa reacción no está disponible.' });
      const now = Date.now();
      const lastAt = room.emoteCooldowns[player.id] || 0;
      if (now - lastAt < 900) return send(res, 429, { error: 'Espera un momento antes de enviar otra reacción.' });
      room.emoteCooldowns[player.id] = now;
      const emote = { id: uid(), playerId: player.id, playerName: player.name, avatarIndex: Number.isInteger(player.avatarIndex) ? player.avatarIndex : 0, emoji, at: now };
      room.emotes ||= [];
      room.emotes.push(emote);
      room.emotes = room.emotes.slice(-12);
      room.version++;
      room.lastActivity = now;
      return send(res, 200, { ok: true, emote, state: serialize(room, player.id) });
    }
    if (url.pathname === '/api/start' && req.method === 'POST') {
      const body = await readBody(req); const room = requireRoom(body.roomId);
      if (room.hostId !== body.playerId) return send(res, 403, { error: 'Solo quien creó la sala puede iniciar.' });
      if (room.started) return send(res, 400, { error: 'La partida ya comenzó.' });
      if (room.players.length < 2) return send(res, 400, { error: 'Necesitan al menos 2 jugadores.' });
      room.deck = makeDeck(); room.discard = []; room.started = true; room.bionicPlayed = false; room.finished = false; room.winnerId = null; room.winnerRecordedForGame = false;
      for (const player of room.players) fillHand(room, player);
      room.currentPlayerId = room.players[0].id;
      log(room, '¡Comienza la partida! Cada jugador recibe tres cartas.');
      log(room, `Turno de ${room.players[0].name}.`);
      runAITurn(room.id);
      // Snapshot inmediato: sirve como punto de partida para que el cliente
      // no descarte por error la primera jugada de IA como si fuera antigua.
      return send(res, 200, { ok: true, state: serialize(room, body.playerId) });
    }
    if (url.pathname === '/api/rematch' && req.method === 'POST') {
      const body = await readBody(req); const room = requireRoom(body.roomId);
      if (room.hostId !== body.playerId) return send(res, 403, { error: 'Solo quien creó la sala puede iniciar la revancha.' });
      resetForRematch(room);
      runAITurn(room.id);
      return send(res, 200, { ok: true, state: serialize(room, body.playerId) });
    }
    if (url.pathname === '/api/action' && req.method === 'POST') {
      const body = await readBody(req); const room = requireRoom(body.roomId); const player = getPlayer(room, body.playerId);
      if (!player) return send(res, 403, { error: 'No perteneces a esta sala.' });
      validateTurn(room, player.id);
      const playedCard = body.action?.type === 'play' ? player.hand.find(c => c.id === body.action.cardId) : null;
      if (body.action?.type === 'discard') {
        const ids = Array.isArray(body.action.cardIds) ? [...new Set(body.action.cardIds)] : [];
        if (!ids.length || ids.length > player.hand.length) throw new Error('Selecciona al menos una carta para descartar.');
        const cards = ids.map(id => player.hand.find(c => c.id === id));
        if (cards.some(c => !c)) throw new Error('Una de las cartas seleccionadas ya no está en tu mano.');
        for (const card of cards) { player.hand = player.hand.filter(c => c.id !== card.id); room.discard.push(card); }
        log(room, `${player.name} descartó ${cards.length} carta${cards.length > 1 ? 's' : ''}.`, player.id);
      } else if (body.action?.type === 'play') {
        playCard(room, player, body.action);
      } else {
        throw new Error('Acción no reconocida.');
      }
      const ownActionLog = room.log.find(entry => entry.actorId === player.id);
      if (ownActionLog) {
        const submitted = body.action || {};
        let effect = submitted.type === 'discard' ? 'discard' : 'treatment';
        let targetPlayerId = null, targetOrganId = null;
        if (submitted.type === 'play' && playedCard) {
          if (playedCard.kind === 'virus') effect = 'virus';
          else if (playedCard.kind === 'medicine') {
            targetPlayerId = player.id;
            targetOrganId = submitted.organId || null;
            const affected = organById(player, targetOrganId);
            effect = affected && isImmunized(affected) && affected.viruses.length === 0 ? 'immunization' : 'medicine';
          } else if (playedCard.kind === 'treatment') {
            effect = playedCard.treatment === 'shield' ? 'shield'
              : playedCard.treatment === 'matasanos' ? 'matasanos'
              : playedCard.treatment === 'spread' ? 'virus' : 'treatment';
          } else if (playedCard.kind === 'organ') effect = 'organ';
          targetPlayerId = submitted.targetPlayerId || targetPlayerId;
          targetOrganId = submitted.organId || targetOrganId;
          if (effect === 'shield') targetPlayerId = player.id;
        }
        room.lastMove = {
          id: ownActionLog.id || uid(), playerId: player.id, playerName: player.name,
          message: ownActionLog.message, at: ownActionLog.at, effect,
          targetPlayerId, targetOrganId, cardKind: playedCard?.kind || null, color: playedCard?.color || null
        };
        const actionEvent = (room.actionEvents || []).find(event => event.id === room.lastMove.id);
        if (actionEvent) Object.assign(actionEvent, room.lastMove, { isAI: Boolean(player.isAI), avatarIndex: Number.isInteger(player.avatarIndex) ? player.avatarIndex : 0 });
      }
      if (!room.finished) {
        fillHand(room, player);
        nextTurn(room);
        runAITurn(room.id);
      }
      room.version++;
      return send(res, 200, { ok: true, state: serialize(room, player.id) });
    }
    if (url.pathname === '/api/leave' && req.method === 'POST') {
      const body = await readBody(req); const room = requireRoom(body.roomId);
      const idx = room.players.findIndex(p => p.id === body.playerId);
      if (idx >= 0) {
        const leaving = room.players[idx]; room.discard.push(...leaving.hand); room.players.splice(idx, 1);
        if (room.hostId === leaving.id && room.players.length) room.hostId = room.players[0].id;
        if (room.currentPlayerId === leaving.id && room.players.length) room.currentPlayerId = room.players[idx % room.players.length].id;
        log(room, `${leaving.name} salió de la sala.`);
        if (room.players.length === 1 && room.started && !room.finished) finishGame(room, room.players[0], `🏆 ${room.players[0].name} gana porque es el último jugador en la sala.`);
        if (room.players.length === 0) rooms.delete(room.id);
      }
      return send(res, 200, { ok: true });
    }
    if (url.pathname === '/api/ping' && req.method === 'GET') return send(res, 200, { ok: true });

    const filePath = url.pathname === '/' ? path.join(ROOT, 'index.html') : path.join(ROOT, path.normalize(url.pathname).replace(/^([/\\])+/, ''));
    if (!filePath.startsWith(ROOT)) return send(res, 403, { error: 'No permitido.' });
    fs.readFile(filePath, (err, data) => {
      if (err) return send(res, 404, { error: 'No encontrado.' });
      const ext = path.extname(filePath).toLowerCase();
      const type = ext === '.html' ? 'text/html; charset=utf-8' : ext === '.css' ? 'text/css; charset=utf-8' : ext === '.js' ? 'text/javascript; charset=utf-8' : ext === '.webp' ? 'image/webp' : ext === '.svg' ? 'image/svg+xml' : ext === '.mp3' ? 'audio/mpeg' : ext === '.ogg' ? 'audio/ogg' : 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store' }); res.end(data);
    });
  } catch (err) {
    send(res, 400, { error: err.message || 'Ocurrió un error.' });
  }
});

setInterval(() => {
  const cutoff = Date.now() - 6 * 60 * 60 * 1000;
  for (const [id, room] of rooms) if (room.lastActivity < cutoff) rooms.delete(id);
}, 30 * 60 * 1000).unref();

if (require.main === module) {
  server.listen(PORT, HOST, () => {
    console.log(`Servidor listo en http://localhost:${PORT}`);
    console.log('Para jugar desde otros celulares de la misma Wi-Fi, usa la IP local de este computador.');
  });
}

module.exports = { makeDeck, isImmunized, playerHasWon, checkWinner, finishGame, resetForRematch, playCard, serialize, log, COLORS, TREATMENTS, rooms, server };
