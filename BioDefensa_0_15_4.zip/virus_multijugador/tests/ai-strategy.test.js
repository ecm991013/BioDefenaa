'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const game = require('../server');

function room(botHand, botOrgans = [], rivalHand = [], rivalOrgans = [], mode = 'immunity') {
  const bot = { id: 'ai', name: 'NEXUS', isAI: true, hand: botHand, organs: botOrgans };
  const rival = { id: 'human', name: 'Ana', isAI: false, hand: rivalHand, organs: rivalOrgans };
  return {
    players: [bot, rival], mode, bionicPlayed: false, deck: [], discard: [],
    log: [], actionEvents: [], version: 1, lastActivity: Date.now(),
    finished: false, wins: {}, currentPlayerId: 'ai'
  };
}
const organ = (id, color, extra = {}) => ({ id, color, shielded: false, viruses: [], medicines: [], ...extra });
const card = (id, kind, extra = {}) => ({ id, kind, ...extra });

test('la IA usa un segundo virus para destruir un órgano rival ya infectado', () => {
  const r = room([card('v', 'virus', { color: 'rojo' })], [], [], [organ('heart', 'rojo', { viruses: [card('v0', 'virus', { color: 'rojo' })] })]);
  game.chooseAIMove(r, r.players[0]);
  assert.equal(r.players[1].organs.length, 0);
  assert.match(r.log[0].message, /destruyó el órgano/i);
});

test('la IA prioriza proteger un órgano inmunizado con Blindaje', () => {
  const r = room([card('shield', 'treatment', { treatment: 'shield' })], [organ('heart', 'rojo', { medicines: [card('m1', 'medicine'), card('m2', 'medicine')] })]);
  game.chooseAIMove(r, r.players[0]);
  assert.equal(r.players[0].organs[0].shielded, true);
});

test('la IA aprovecha Extracción para obtener un órgano faltante', () => {
  const r = room([card('steal', 'treatment', { treatment: 'steal' })], [], [], [organ('brain', 'azul', { medicines: [card('m1', 'medicine'), card('m2', 'medicine')] })]);
  game.chooseAIMove(r, r.players[0]);
  assert.equal(r.players[0].organs.some(o => o.id === 'brain'), true);
  assert.equal(r.players[1].organs.length, 0);
});

test('la IA usa Matasanos contra un órgano rival blindado', () => {
  const r = room([card('m', 'treatment', { treatment: 'matasanos' })], [], [], [organ('heart', 'rojo', { shielded: true, medicines: [card('m1', 'medicine'), card('m2', 'medicine')] })]);
  game.chooseAIMove(r, r.players[0]);
  assert.equal(r.players[1].organs[0].shielded, false);
  assert.equal(r.players[1].organs[0].medicines.length, 2);
});


test('las IA no se atacan entre ellas y priorizan a los jugadores humanos', () => {
  const r = room([card('virus', 'virus', { color: 'rojo' })], [], [], [organ('human-heart', 'rojo')]);
  const rivalAI = { id: 'ai-2', name: 'ATLAS', isAI: true, hand: [], organs: [organ('ai-heart', 'rojo')] };
  r.players.push(rivalAI);
  game.chooseAIMove(r, r.players[0]);
  assert.equal(r.players[1].organs[0].viruses.length, 1, 'la IA debe atacar al jugador humano');
  assert.equal(rivalAI.organs.length, 1, 'la otra IA no debe recibir ataques');
});

test('la IA no selecciona a otra IA como objetivo si no hay jugadores humanos', () => {
  const r = room([card('virus', 'virus', { color: 'rojo' })], [], [], [organ('ai-heart', 'rojo')]);
  r.players[1].isAI = true;
  game.chooseAIMove(r, r.players[0]);
  assert.equal(r.players[1].organs.length, 1);
  assert.equal(r.log[0].message.includes('destruyó'), false);
});
