BIODEFENSA 0.12.1 - JUEGO DE CARTAS MULTIJUGADOR

CONTENIDO
- index.html: interfaz web, catálogo de cartas y efectos visuales.
- server.js: servidor Node.js, salas y reglas autoritativas de las partidas.
- assets/: cartas, avatares, fondos, música y sonidos.
- package.json: comando de inicio compatible con plataformas Node.js como Render.
- render.yaml: configuración inicial de servicio web para Render.

EJECUCIÓN LOCAL
1. Instala Node.js 20 o superior.
2. Abre una terminal en esta carpeta.
3. Ejecuta: npm start
4. Abre: http://localhost:3000

PUBLICACIÓN EN RENDER
1. Sube el contenido de esta carpeta a un repositorio de GitHub.
2. En Render crea un servicio Web Service y conecta el repositorio.
3. Runtime: Node. Build command: npm install. Start command: npm start.
4. Render asignará PORT automáticamente. El servidor ya escucha en 0.0.0.0.

NOVEDADES 0.12.1
- Dos Blindajes y dos Matasanos en cada mazo (74 cartas en total).
- Blindaje solo se puede aplicar a un órgano sano e inmunizado.
- Un órgano blindado no puede ser extraído ni intercambiado con Intercambio orgánico.
- Cambio de cuerpo sigue pudiendo intercambiar órganos blindados.
- Matasanos elimina exclusivamente el blindaje. Conserva las medicinas y la inmunización.
- Estado de blindaje visible en el tablero.
- Efectos visuales sincronizados para virus, medicina, inmunización, Blindaje y Matasanos.

NOTA DE MULTIJUGADOR
La sincronización actual usa sondeo HTTP periódico. Las salas y sus partidas se mantienen en memoria del proceso; un reinicio del servidor puede cerrar las partidas activas. Esta versión todavía no incluye persistencia de partidas.
