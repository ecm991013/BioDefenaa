BIODEFENSA 0.12.11 - JUEGO DE CARTAS MULTIJUGADOR

CONTENIDO
- index.html: interfaz web, catálogo de cartas y efectos visuales.
- server.js: servidor Node.js, salas y reglas autoritativas de las partidas.
- assets/: cartas, avatares, fondos, música y sonidos.
- package.json: comando de inicio compatible con plataformas Node.js como Render.
- render.yaml: configuración inicial de servicio web para Render.

EJECUCIÓN LOCAL
1. Instala Node.js 20 o superior.
2. Abre una terminal en esta carpeta.
3. Ejecuta: npm start
4. Abre: http://localhost:3000

PUBLICACIÓN EN RENDER
1. Sube el contenido de esta carpeta a un repositorio de GitHub.
2. En Render crea un servicio Web Service y conecta el repositorio.
3. Runtime: Node. Build command: npm install. Start command: npm start.
4. Render asignará PORT automáticamente. El servidor ya escucha en 0.0.0.0.

NOVEDADES 0.12.1
- Dos Blindajes y dos Matasanos en cada mazo (74 cartas en total).
- Blindaje solo se puede aplicar a un órgano sano e inmunizado.
- Un órgano blindado no puede ser extraído ni intercambiado con Intercambio orgánico.
- Cambio de cuerpo sigue pudiendo intercambiar órganos blindados.
- Matasanos elimina exclusivamente el blindaje. Conserva las medicinas y la inmunización.
- Estado de blindaje visible en el tablero.
- Efectos visuales sincronizados para virus, medicina, inmunización, Blindaje y Matasanos.

NOTA DE MULTIJUGADOR
La sincronización actual usa sondeo HTTP periódico. Las salas y sus partidas se mantienen en memoria del proceso; un reinicio del servidor puede cerrar las partidas activas. Esta versión todavía no incluye persistencia de partidas.


MODO CONTRA IA (0.12.4)
- En la pantalla principal pulsa "Jugar contra IA".
- Elige entre 1 y 5 rivales en el selector "Rivales de IA".
- Elige el modo Clásico o Inmunización y pulsa "Jugar contra IA".
- La partida se inicia en una sala privada; los rivales juegan automáticamente por turnos.
- Los rivales de IA usan las reglas del servidor y pueden colocar órganos, curarse, inmunizarse e infectar órganos rivales.

NOVEDADES 0.12.11
- Las burbujas de movimiento solo se muestran a los demás jugadores; quien realiza la jugada no ve su propio aviso.
- Las acciones de la IA se registran como movimientos y aparecen en la misma burbuja superior.
- Los avisos flotantes desaparecen automáticamente después de unos segundos.
- La burbuja muestra el nombre y avatar del jugador o rival de IA que realizó la acción.


Versión 0.12.11:
- Modo clásico: el mazo ya no incluye cartas de Virus.
- Al abandonar el jugador cuyo turno está activo, la partida avanza y activa el turno de IA si corresponde.
- Propagación genera una sola notificación de resultado.
- La IA puede usar Matasanos, Extracción y Guantes de cuarentena cuando son útiles.
- Se elimina __testboot.html del paquete de producción.
