const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');

test('la interfaz incluye transiciones visuales de turno y cartas nuevas', () => {
  assert.match(html, /function markVisualTransitions\(previous,next\)/);
  assert.match(html, /turnbanner\.turn-change/);
  assert.match(html, /cardDrawIn/);
  assert.match(html, /player-board\.turn-arrive/);
});

test('la pantalla final diferencia victoria y derrota y respeta movimiento reducido', () => {
  assert.match(html, /is-victory/);
  assert.match(html, /is-defeat/);
  assert.match(html, /prefers-reduced-motion:reduce/);
});


test('la interfaz reconecta sesiones guardadas y reintenta ante fallos temporales', () => {
  assert.match(html, /api\('\/api\/reconnect'/);
  assert.match(html, /Conexión interrumpida\. Intentando reconectar/);
  assert.match(html, /Math\.pow\(2,Math\.min\(pollFailures-1,4\)\)/);
  assert.match(html, /document\.hidden\?3000:\(next\.started\?1000:1800\)/);
});
