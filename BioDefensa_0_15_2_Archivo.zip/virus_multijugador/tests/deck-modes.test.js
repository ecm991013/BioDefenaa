'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { makeDeck } = require('../server');

test('classic deck has no virus cards', () => {
  const deck = makeDeck('classic');
  assert.equal(deck.filter(c => c.kind === 'virus').length, 0);
});

test('immunity deck retains colored and universal viruses', () => {
  const deck = makeDeck('immunity');
  assert.equal(deck.filter(c => c.kind === 'virus').length, 18);
});
