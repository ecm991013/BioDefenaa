'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const fsSync = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const testDataDir = fsSync.mkdtempSync(path.join(os.tmpdir(), 'biodefensa-persist-suite-'));
process.env.BIODEFENSA_DATA_DIR = testDataDir;
const game = require('../server');

test('las salas se guardan y se restauran con mazo, descarte, manos y órganos', async () => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'biodefensa-persist-'));
  const file = path.join(directory, 'rooms.json');
  const room = {
    id: 'ABCDE', hostId: 'human', mode: 'immunity', bionicPlayed: false,
    players: [
      { id: 'human', name: 'Ana', avatarIndex: 2, hand: [{ id: 'c1', kind: 'medicine', color: 'rojo' }], organs: [{ id: 'o1', color: 'rojo', viruses: [], medicines: [] }], lastSeenAt: Date.now(), online: true },
      { id: 'bot', name: 'NEXUS', avatarIndex: 4, isAI: true, hand: [], organs: [], lastSeenAt: Date.now(), online: true }
    ],
    deck: [{ id: 'c2', kind: 'organ', color: 'azul' }],
    discard: [{ id: 'c3', kind: 'virus', color: 'verde' }],
    started: true, finished: false, winnerId: null, currentPlayerId: 'human',
    log: [{ id: 'l1', message: 'Partida iniciada', at: Date.now() }], actionEvents: [],
    emotes: [], emoteCooldowns: {}, wins: {}, version: 7, lastActivity: Date.now()
  };
  try {
    await game.saveRoomsToFile(file, [room]);
    const restored = new Map();
    const count = await game.loadRoomsFromFile(file, restored, { markOffline: true });
    assert.equal(count, 1);
    const loaded = restored.get('ABCDE');
    assert.equal(loaded.deck[0].id, 'c2');
    assert.equal(loaded.discard[0].id, 'c3');
    assert.equal(loaded.players[0].hand[0].id, 'c1');
    assert.equal(loaded.players[0].organs[0].id, 'o1');
    const view = game.serialize(loaded, 'human');
    assert.equal(view.players.find(player => player.id === 'human').online, false);
    assert.equal(view.players.find(player => player.id === 'bot').online, true);
  } finally {
    await fs.rm(directory, { recursive: true, force: true });
  }
});

test('el restaurador descarta salas inactivas durante más de seis horas', async () => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'biodefensa-expired-'));
  const file = path.join(directory, 'rooms.json');
  try {
    await game.saveRoomsToFile(file, [{ id: 'OLD00', players: [{ id: 'p1' }], lastActivity: Date.now() - 7 * 60 * 60 * 1000 }]);
    const restored = new Map();
    const count = await game.loadRoomsFromFile(file, restored, { markOffline: true });
    assert.equal(count, 0);
    assert.equal(restored.size, 0);
  } finally {
    await fs.rm(directory, { recursive: true, force: true });
  }
});

test('el endpoint de reconexión vuelve a marcar conectado al jugador recuperado', async t => {
  const server = game.server;
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  t.after(async () => {
    game.rooms.clear();
    await game.flushPersistence().catch(() => {});
    await new Promise(resolve => server.close(resolve));
    await fs.rm(testDataDir, { recursive: true, force: true });
  });
  const address = server.address();
  const base = `http://127.0.0.1:${address.port}`;
  const registerResponse = await fetch(`${base}/api/register`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'ana_test', password: 'clave-segura-123', displayName: 'Ana' })
  });
  const registered = await registerResponse.json();
  assert.equal(registerResponse.status, 201);
  const createdResponse = await fetch(`${base}/api/create`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${registered.token}` },
    body: JSON.stringify({ mode: 'classic' })
  });
  const created = await createdResponse.json();
  assert.equal(createdResponse.status, 200);
  const room = game.rooms.get(created.roomId);
  room.started = true;
  room.players[0].lastSeenAt = 0;
  room.players[0].online = false;
  const reconnectResponse = await fetch(`${base}/api/reconnect`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ roomId: created.roomId, playerId: created.playerId })
  });
  const reconnect = await reconnectResponse.json();
  assert.equal(reconnectResponse.status, 200);
  assert.equal(reconnect.reconnected, true);
  assert.equal(reconnect.state.players[0].online, true);
});
