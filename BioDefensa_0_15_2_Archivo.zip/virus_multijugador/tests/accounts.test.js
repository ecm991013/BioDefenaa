'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { once } = require('node:events');
const app = require('../server');
let base;
async function request(route, { method='GET', body }={}) {
  const headers={}; if(body)headers['Content-Type']='application/json';
  const response=await fetch(base+route,{method,headers,body:body?JSON.stringify(body):undefined});
  return {status:response.status,data:await response.json()};
}
test('permite crear salas, jugar contra IA y unirse sin crear una cuenta', async t => {
  app.server.listen(0,'127.0.0.1'); await once(app.server,'listening');
  base=`http://127.0.0.1:${app.server.address().port}`;
  t.after(async()=>{await new Promise(resolve=>app.server.close(resolve));});
  const created=await request('/api/create',{method:'POST',body:{name:'Invitado',avatarIndex:3,mode:'classic'}});
  assert.equal(created.status,200);
  const room=app.rooms.get(created.data.roomId);
  assert.equal(room.players[0].name,'Invitado');
  assert.equal(room.players[0].avatarIndex,3);
  assert.equal(room.players[0].accountId,undefined);
  const joined=await request('/api/join',{method:'POST',body:{name:'Segundo',roomId:created.data.roomId,avatarIndex:2}});
  assert.equal(joined.status,200);
  assert.equal(room.players[1].name,'Segundo');
  const ai=await request('/api/create-ai',{method:'POST',body:{name:'Agente',avatarIndex:1,rivalCount:2}});
  assert.equal(ai.status,200);
  const aiRoom=app.rooms.get(ai.data.roomId);
  assert.equal(aiRoom.players.length,3);
  assert.equal(aiRoom.players[0].name,'Agente');
});
