BIODEFENSA 0.14.0 - JUEGO DE CARTAS MULTIJUGADOR

CONTENIDO
- index.html: interfaz web, catálogo de cartas y efectos visuales.
- server.js: servidor Node.js, salas y reglas autoritativas de las partidas.
- assets/: cartas, avatares, fondos, música y sonidos.
- package.json: comando de inicio compatible con plataformas Node.js como Render.
- render.yaml: configuración inicial de servicio web para Render.

EJECUCIÓN LOCAL
1. Instala Node.js 20 o superior.
2. Abre una terminal en esta carpeta.
3. Ejecuta: npm start
4. Abre: http://localhost:3000

PUBLICACIÓN EN RENDER (FLUJO CON ZIP)
1. Sube BioDefensa_0_14_0.zip a la raíz del repositorio de GitHub.
2. Coloca en la raíz del repositorio el render.yaml descargado para esta versión.
3. El buildCommand del archivo extrae el ZIP y el startCommand inicia virus_multijugador/server.js.
4. Guarda los cambios del repositorio y deja que Render ejecute el nuevo despliegue.
5. Para conservar salas después de reemplazar la instancia, configura almacenamiento persistente y BIODEFENSA_DATA_DIR como se explica en CONFIGURAR_PERSISTENCIA_RENDER_0_14_0.txt.

NOVEDADES 0.12.1
- Dos Blindajes y dos Matasanos en cada mazo (74 cartas en total).
- Blindaje solo se puede aplicar a un órgano sano e inmunizado.
- Un órgano blindado no puede ser extraído ni intercambiado con Intercambio orgánico.
- Cambio de cuerpo sigue pudiendo intercambiar órganos blindados.
- Matasanos elimina exclusivamente el blindaje. Conserva las medicinas y la inmunización.
- Estado de blindaje visible en el tablero.
- Efectos visuales sincronizados para virus, medicina, inmunización, Blindaje y Matasanos.

ESTABILIDAD ONLINE 0.14.0
- Las salas completas se guardan automáticamente en data/rooms.json (o en BIODEFENSA_DATA_DIR si se configura otra ruta).
- Al iniciar el servidor se restauran las salas guardadas que hayan tenido actividad durante las últimas seis horas.
- Los jugadores se marcan como desconectados durante un reinicio y vuelven a aparecer conectados cuando recuperan su sesión.
- La sesión del navegador conserva el código de sala y el identificador de jugador para permitir la reconexión.
- Si la red falla temporalmente, el cliente reintenta con espera progresiva y muestra cuándo vuelve la conexión.
- El sondeo es adaptativo: consulta con menor frecuencia en el lobby y cuando la pestaña está en segundo plano.
- El servidor guarda cambios de forma agrupada, escribe mediante archivo temporal y renombrado atómico, y realiza un guardado final al recibir SIGTERM o SIGINT.

IMPORTANTE PARA PUBLICACIÓN ONLINE
La persistencia en archivo necesita almacenamiento persistente en la plataforma de alojamiento para sobrevivir a reemplazos de instancia o nuevos despliegues. En Render, si el servicio tiene un disco persistente disponible, móntalo por ejemplo en /var/data y configura BIODEFENSA_DATA_DIR=/var/data. Sin un disco persistente, el archivo local puede perderse al reemplazar la instancia.

La arquitectura sigue funcionando como una sola instancia de Node.js y mantiene el máximo actual de seis jugadores por sala. La persistencia permite recuperar salas después de reiniciar esa instancia, pero no sincroniza varias instancias simultáneas. Antes de escalar horizontalmente se debe migrar el estado compartido a una base de datos/servicio central como PostgreSQL y coordinar los cambios entre instancias.


MODO CONTRA IA (0.12.4)
- En la pantalla principal pulsa "Jugar contra IA".
- Elige entre 1 y 5 rivales en el selector "Rivales de IA".
- Elige el modo Clásico o Inmunización y pulsa "Jugar contra IA".
- La partida se inicia en una sala privada; los rivales juegan automáticamente por turnos.
- Los rivales de IA usan las reglas del servidor y pueden colocar órganos, curarse, inmunizarse e infectar órganos rivales.

NOVEDADES 0.13.1 - EXPERIENCIA DE JUEGO
- Transición visual al cambiar el jugador en turno, con realce del banner y del tablero activo.
- Animación de entrada para las cartas nuevas que llegan a la mano.
- Entrada animada para los mensajes de jugadas de otros jugadores.
- Presentación de victoria con realce del trofeo y destellos.
- Presentación de derrota diferenciada, con tratamiento visual más sobrio.
- Respeto por la preferencia del sistema de reducir movimiento.

NOVEDADES 0.12.11
- Las burbujas de movimiento solo se muestran a los demás jugadores; quien realiza la jugada no ve su propio aviso.
- Las acciones de la IA se registran como movimientos y aparecen en la misma burbuja superior.
- Los avisos flotantes desaparecen automáticamente después de unos segundos.
- La burbuja muestra el nombre y avatar del jugador o rival de IA que realizó la acción.


Versión 0.12.11:
- Modo clásico: el mazo ya no incluye cartas de Virus.
- Al abandonar el jugador cuyo turno está activo, la partida avanza y activa el turno de IA si corresponde.
- Propagación genera una sola notificación de resultado.
- La IA puede usar Matasanos, Extracción y Guantes de cuarentena cuando son útiles.
- Se elimina __testboot.html del paquete de producción.


NOVEDADES 0.13.0 - INTELIGENCIA ARTIFICIAL
- La IA evalúa el progreso propio y el de sus rivales antes de elegir una jugada.
- Utiliza Blindaje para proteger órganos inmunizados y Matasanos para retirar blindajes rivales.
- Usa Extracción para obtener órganos que le faltan y prioriza órganos valiosos.
- Puede utilizar Intercambio orgánico o Cambio de cuerpo cuando la operación mejora su cuerpo.
- Usa Propagación y virus para atacar órganos vulnerables; reconoce oportunidades de destruir órganos con una segunda infección.
- Cura sus órganos infectados e intenta completar su inmunización.
- Puede usar Guantes de cuarentena cuando hay rivales cerca de ganar y conviene interrumpir su ritmo.
- Si no encuentra una jugada útil, descarta con una prioridad que intenta conservar cartas aprovechables.
- Se mantienen las reglas y la validación de jugadas en el servidor.

ALCANCE DE LAS PRUEBAS 0.13.0
- Se ejecutaron pruebas automatizadas de reglas y decisiones estratégicas de IA.
- No se realizó una prueba visual completa en navegador ni una partida online prolongada.

NOVEDADES 0.14.0 - ESTABILIDAD ONLINE
- Persistencia de salas: jugadores, manos, órganos, mazo, descarte, turno, historial y podio.
- Recuperación de salas guardadas al iniciar el servidor; se descartan salas con más de seis horas sin actividad.
- Endpoint de reconexión de jugadores usando el código de sala y el ID de sesión que conserva el navegador.
- Indicador de conexión en el lobby para jugadores humanos e IA.
- Reintentos automáticos con espera progresiva cuando hay cortes de red; no se cierra la sesión por el primer error temporal.
- Frecuencia de consulta adaptativa para reducir solicitudes en lobby y pestañas en segundo plano.
- Guardado atómico, escritura agrupada y cierre ordenado del servidor.

LIMITACIÓN CONOCIDA
- Para conservar datos después de reemplazar una instancia en la nube, BIODEFENSA_DATA_DIR debe apuntar a almacenamiento persistente proporcionado por el host.
- Esta versión mejora la resiliencia de una instancia; todavía no coordina múltiples instancias en paralelo.


BIODEFENSA 0.15.0 — CUENTAS Y PERFILES
- Crea una cuenta desde la pantalla inicial o inicia sesión con tu usuario.
- La contraseña debe tener al menos 8 caracteres. Usa una contraseña única.
- El perfil muestra nivel, XP, partidas, victorias, derrotas y porcentaje de victorias.
- Las cuentas se guardan en BIODEFENSA_DATA_DIR/accounts.json. Mantén esa ruta en tu disco persistente de Render.
- Ganar otorga 100 XP y perder 35 XP. Las estadísticas se registran al terminar la partida.
- Las cuentas antiguas de la versión 0.14.0 no existen automáticamente: cada jugador debe registrarse.
- Usa HTTPS para el despliegue público. No hay recuperación de contraseña en esta versión.
